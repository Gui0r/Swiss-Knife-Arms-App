import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../widgets/custom_card.dart';
import '../widgets/custom_button.dart';

class CurrencyConverterScreen extends StatefulWidget {
  const CurrencyConverterScreen({super.key});

  @override
  State<CurrencyConverterScreen> createState() => _CurrencyConverterScreenState();
}

class _CurrencyConverterScreenState extends State<CurrencyConverterScreen> {
  final TextEditingController _amountController = TextEditingController();
  final TextEditingController _resultController = TextEditingController();
  
  String _fromCurrency = 'USD';
  String _toCurrency = 'BRL';
  bool _isLoading = false;
  String _lastUpdate = '';
  Map<String, double> _exchangeRates = {};
  
  final List<String> _currencies = [
    'USD', 'EUR', 'GBP', 'JPY', 'AUD', 'CAD', 'CHF', 'CNY', 'SEK', 'NZD',
    'BRL', 'MXN', 'INR', 'RUB', 'KRW', 'SGD', 'HKD', 'NOK', 'TRY', 'ZAR',
    'DKK', 'PLN', 'TWD', 'THB', 'MYR', 'PHP', 'CZK', 'HUF', 'ILS', 'CLP',
    'PKR', 'BGN', 'RON', 'HRK', 'ISK', 'UAH', 'LTL', 'LVL', 'EEK', 'SKK'
  ];

  final Map<String, String> _currencyNames = {
    'USD': 'Dólar Americano',
    'EUR': 'Euro',
    'GBP': 'Libra Esterlina',
    'JPY': 'Iene Japonês',
    'AUD': 'Dólar Australiano',
    'CAD': 'Dólar Canadense',
    'CHF': 'Franco Suíço',
    'CNY': 'Yuan Chinês',
    'SEK': 'Coroa Sueca',
    'NZD': 'Dólar Neozelandês',
    'BRL': 'Real Brasileiro',
    'MXN': 'Peso Mexicano',
    'INR': 'Rupia Indiana',
    'RUB': 'Rublo Russo',
    'KRW': 'Won Sul-Coreano',
    'SGD': 'Dólar de Singapura',
    'HKD': 'Dólar de Hong Kong',
    'NOK': 'Coroa Norueguesa',
    'TRY': 'Lira Turca',
    'ZAR': 'Rand Sul-Africano',
  };

  @override
  void initState() {
    super.initState();
    _amountController.addListener(_convertCurrency);
    _loadExchangeRates();
  }

  @override
  void dispose() {
    _amountController.dispose();
    _resultController.dispose();
    super.dispose();
  }

  Future<void> _loadExchangeRates() async {
    setState(() {
      _isLoading = true;
    });

    try {
      // Usando uma API gratuita para taxas de câmbio
      final response = await http.get(
        Uri.parse('https://api.exchangerate-api.com/v4/latest/USD'),
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          _exchangeRates = Map<String, double>.from(data['rates']);
          _lastUpdate = data['date'] ?? 'N/A';
        });
        _convertCurrency();
      } else {
        _showError('Erro ao carregar taxas de câmbio');
      }
    } catch (e) {
      _showError('Erro de conexão: ${e.toString()}');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _convertCurrency() {
    final amount = double.tryParse(_amountController.text);
    if (amount == null || amount <= 0 || _exchangeRates.isEmpty) {
      _resultController.text = '';
      return;
    }

    try {
      // Converter para USD primeiro, depois para a moeda de destino
      double usdAmount = amount;
      if (_fromCurrency != 'USD') {
        usdAmount = amount / _exchangeRates[_fromCurrency]!;
      }

      double result = usdAmount;
      if (_toCurrency != 'USD') {
        result = usdAmount * _exchangeRates[_toCurrency]!;
      }

      _resultController.text = result.toStringAsFixed(4);
    } catch (e) {
      _resultController.text = 'Erro no cálculo';
    }
  }

  void _swapCurrencies() {
    setState(() {
      final temp = _fromCurrency;
      _fromCurrency = _toCurrency;
      _toCurrency = temp;
    });
    _convertCurrency();
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Conversor de Moedas'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadExchangeRates,
            tooltip: 'Atualizar taxas',
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Theme.of(context).colorScheme.primary.withOpacity(0.1),
              Theme.of(context).colorScheme.secondary.withOpacity(0.1),
            ],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Status Card
                CustomCard(
                  child: Row(
                    children: [
                      Icon(
                        _isLoading ? Icons.sync : Icons.check_circle,
                        color: _isLoading ? Colors.orange : Colors.green,
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              _isLoading ? 'Carregando taxas...' : 'Taxas atualizadas',
                              style: Theme.of(context).textTheme.titleSmall?.copyWith(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            if (_lastUpdate.isNotEmpty)
                              Text(
                                'Última atualização: $_lastUpdate',
                                style: Theme.of(context).textTheme.bodySmall,
                              ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                // From Currency
                CustomCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'De:',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Expanded(
                            flex: 2,
                            child: TextField(
                              controller: _amountController,
                              keyboardType: const TextInputType.numberWithOptions(decimal: true),
                              inputFormatters: [
                                FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d*')),
                              ],
                              decoration: const InputDecoration(
                                border: OutlineInputBorder(),
                                hintText: 'Digite o valor',
                                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: DropdownButtonFormField<String>(
                              value: _fromCurrency,
                              decoration: const InputDecoration(
                                border: OutlineInputBorder(),
                                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                              ),
                              items: _currencies.map((String currency) {
                                return DropdownMenuItem<String>(
                                  value: currency,
                                  child: Text(currency),
                                );
                              }).toList(),
                              onChanged: (String? newValue) {
                                if (newValue != null) {
                                  setState(() {
                                    _fromCurrency = newValue;
                                  });
                                  _convertCurrency();
                                }
                              },
                            ),
                          ),
                        ],
                      ),
                      if (_currencyNames.containsKey(_fromCurrency))
                        Text(
                          _currencyNames[_fromCurrency]!,
                          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: Theme.of(context).colorScheme.primary,
                          ),
                        ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                // Swap Button
                Center(
                  child: CustomButton(
                    text: 'Trocar',
                    icon: Icons.swap_vert,
                    onPressed: _swapCurrencies,
                    backgroundColor: Theme.of(context).colorScheme.secondary,
                  ),
                ),
                const SizedBox(height: 16),
                // To Currency
                CustomCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Para:',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Expanded(
                            flex: 2,
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                              decoration: BoxDecoration(
                                border: Border.all(color: Colors.grey),
                                borderRadius: BorderRadius.circular(4),
                                color: Theme.of(context).colorScheme.surface,
                              ),
                              child: Text(
                                _resultController.text.isEmpty ? '0.0000' : _resultController.text,
                                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                                  fontWeight: FontWeight.bold,
                                  color: Theme.of(context).colorScheme.primary,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: DropdownButtonFormField<String>(
                              value: _toCurrency,
                              decoration: const InputDecoration(
                                border: OutlineInputBorder(),
                                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                              ),
                              items: _currencies.map((String currency) {
                                return DropdownMenuItem<String>(
                                  value: currency,
                                  child: Text(currency),
                                );
                              }).toList(),
                              onChanged: (String? newValue) {
                                if (newValue != null) {
                                  setState(() {
                                    _toCurrency = newValue;
                                  });
                                  _convertCurrency();
                                }
                              },
                            ),
                          ),
                        ],
                      ),
                      if (_currencyNames.containsKey(_toCurrency))
                        Text(
                          _currencyNames[_toCurrency]!,
                          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: Theme.of(context).colorScheme.primary,
                          ),
                        ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                // Exchange Rate Info
                if (_exchangeRates.isNotEmpty)
                  CustomCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Taxa de Câmbio:',
                          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          '1 $_fromCurrency = ${_getExchangeRate().toStringAsFixed(4)} $_toCurrency',
                          style: Theme.of(context).textTheme.titleSmall?.copyWith(
                            color: Theme.of(context).colorScheme.primary,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                const SizedBox(height: 16),
                // Info Card
                CustomCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Informações:',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        '• As taxas de câmbio são atualizadas diariamente\n'
                        '• Os valores são aproximados e podem variar\n'
                        '• Para transações reais, consulte seu banco\n'
                        '• Toque no ícone de atualização para buscar as últimas taxas',
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  double _getExchangeRate() {
    if (_fromCurrency == _toCurrency) return 1.0;
    
    try {
      double fromRate = _fromCurrency == 'USD' ? 1.0 : _exchangeRates[_fromCurrency]!;
      double toRate = _toCurrency == 'USD' ? 1.0 : _exchangeRates[_toCurrency]!;
      
      return toRate / fromRate;
    } catch (e) {
      return 0.0;
    }
  }
}
