import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../widgets/custom_card.dart';
import '../widgets/custom_button.dart';

class TextToolsScreen extends StatefulWidget {
  const TextToolsScreen({super.key});

  @override
  State<TextToolsScreen> createState() => _TextToolsScreenState();
}

class _TextToolsScreenState extends State<TextToolsScreen> {
  final TextEditingController _inputController = TextEditingController();
  final TextEditingController _outputController = TextEditingController();
  String _selectedTool = 'Contar Caracteres';
  int _characterCount = 0;
  int _wordCount = 0;
  int _lineCount = 0;

  final List<String> _textTools = [
    'Contar Caracteres',
    'Contar Palavras',
    'Contar Linhas',
    'Maiúsculas',
    'Minúsculas',
    'Primeira Letra Maiúscula',
    'Inverter Texto',
    'Remover Espaços',
    'Remover Quebras de Linha',
    'Duplicar Texto',
    'Texto ao Contrário',
  ];

  @override
  void initState() {
    super.initState();
    _inputController.addListener(_updateCounts);
  }

  @override
  void dispose() {
    _inputController.dispose();
    _outputController.dispose();
    super.dispose();
  }

  void _updateCounts() {
    final text = _inputController.text;
    setState(() {
      _characterCount = text.length;
      _wordCount = text.trim().isEmpty ? 0 : text.trim().split(RegExp(r'\s+')).length;
      _lineCount = text.isEmpty ? 0 : text.split('\n').length;
    });
  }

  void _processText() {
    final input = _inputController.text;
    String result = '';

    switch (_selectedTool) {
      case 'Contar Caracteres':
        result = 'Caracteres: $_characterCount\nPalavras: $_wordCount\nLinhas: $_lineCount';
        break;
      case 'Contar Palavras':
        result = 'Total de palavras: $_wordCount';
        break;
      case 'Contar Linhas':
        result = 'Total de linhas: $_lineCount';
        break;
      case 'Maiúsculas':
        result = input.toUpperCase();
        break;
      case 'Minúsculas':
        result = input.toLowerCase();
        break;
      case 'Primeira Letra Maiúscula':
        result = _capitalizeFirstLetter(input);
        break;
      case 'Inverter Texto':
        result = input.split('').reversed.join('');
        break;
      case 'Remover Espaços':
        result = input.replaceAll(' ', '');
        break;
      case 'Remover Quebras de Linha':
        result = input.replaceAll('\n', ' ').replaceAll('\r', '');
        break;
      case 'Duplicar Texto':
        result = input + input;
        break;
      case 'Texto ao Contrário':
        result = input.split('\n').reversed.join('\n');
        break;
    }

    _outputController.text = result;
  }

  String _capitalizeFirstLetter(String text) {
    if (text.isEmpty) return text;
    return text[0].toUpperCase() + text.substring(1).toLowerCase();
  }

  void _copyToClipboard() {
    if (_outputController.text.isNotEmpty) {
      Clipboard.setData(ClipboardData(text: _outputController.text));
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Texto copiado para a área de transferência!')),
      );
    }
  }

  void _clearAll() {
    _inputController.clear();
    _outputController.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Ferramentas de Texto'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Theme.of(context).colorScheme.primary.withOpacity(0.1),
              Theme.of(context).colorScheme.secondary.withOpacity(0.1),
            ],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CustomCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Selecione a ferramenta:',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 12),
                      DropdownButtonFormField<String>(
                        value: _selectedTool,
                        decoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        ),
                        items: _textTools.map((String tool) {
                          return DropdownMenuItem<String>(
                            value: tool,
                            child: Text(tool),
                          );
                        }).toList(),
                        onChanged: (String? newValue) {
                          if (newValue != null) {
                            setState(() {
                              _selectedTool = newValue;
                            });
                          }
                        },
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                CustomCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Texto de entrada:',
                            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            '$_characterCount caracteres',
                            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              color: Theme.of(context).colorScheme.primary,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      TextField(
                        controller: _inputController,
                        maxLines: 6,
                        decoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          hintText: 'Digite ou cole seu texto aqui...',
                          contentPadding: EdgeInsets.all(12),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: CustomButton(
                        text: 'Processar',
                        icon: Icons.transform,
                        onPressed: _processText,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: CustomButton(
                        text: 'Limpar',
                        icon: Icons.clear,
                        onPressed: _clearAll,
                        backgroundColor: Colors.grey,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                CustomCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Resultado:',
                            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          IconButton(
                            onPressed: _copyToClipboard,
                            icon: const Icon(Icons.copy),
                            tooltip: 'Copiar resultado',
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      TextField(
                        controller: _outputController,
                        maxLines: 6,
                        readOnly: true,
                        decoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          hintText: 'O resultado aparecerá aqui...',
                          contentPadding: EdgeInsets.all(12),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                CustomCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Estatísticas do texto:',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          _buildStatCard('Caracteres', _characterCount.toString(), Icons.text_fields),
                          _buildStatCard('Palavras', _wordCount.toString(), Icons.format_align_left),
                          _buildStatCard('Linhas', _lineCount.toString(), Icons.format_line_spacing),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                CustomCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Ferramentas disponíveis:',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        '• Contar caracteres, palavras e linhas\n'
                        '• Converter para maiúsculas/minúsculas\n'
                        '• Capitalizar primeira letra\n'
                        '• Inverter texto\n'
                        '• Remover espaços e quebras de linha\n'
                        '• Duplicar texto\n'
                        '• Copiar resultado para área de transferência',
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStatCard(String title, String value, IconData icon) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          Icon(icon, color: Theme.of(context).colorScheme.primary),
          const SizedBox(height: 4),
          Text(
            value,
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.bold,
              color: Theme.of(context).colorScheme.primary,
            ),
          ),
          Text(
            title,
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ],
      ),
    );
  }
}
