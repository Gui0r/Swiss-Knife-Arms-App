import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../widgets/modern_app_bar.dart';
import '../widgets/modern_card.dart';
import '../widgets/modern_button.dart';
import '../widgets/modern_input.dart';

class UnitConverterScreen extends StatefulWidget {
  const UnitConverterScreen({super.key});

  @override
  State<UnitConverterScreen> createState() => _UnitConverterScreenState();
}

class _UnitConverterScreenState extends State<UnitConverterScreen> with SingleTickerProviderStateMixin {
  final TextEditingController _inputController = TextEditingController();
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  
  String _selectedCategory = 'Comprimento';
  String _fromUnit = 'Metro';
  String _toUnit = 'Quilômetro';
  String _result = '';

  final Map<String, Map<String, double>> _conversionFactors = {
    'Comprimento': {
      'Metro': 1.0,
      'Quilômetro': 0.001,
      'Centímetro': 100.0,
      'Milímetro': 1000.0,
      'Pé': 3.28084,
      'Polegada': 39.3701,
      'Jarda': 1.09361,
      'Milha': 0.000621371,
    },
    'Peso': {
      'Quilograma': 1.0,
      'Grama': 1000.0,
      'Libra': 2.20462,
      'Onça': 35.274,
      'Tonelada': 0.001,
      'Stone': 0.157473,
    },
    'Volume': {
      'Litro': 1.0,
      'Mililitro': 1000.0,
      'Galão (US)': 0.264172,
      'Galão (UK)': 0.219969,
      'Pé cúbico': 0.0353147,
      'Metro cúbico': 0.001,
      'Xícara': 4.22675,
      'Colher de sopa': 67.628,
    },
    'Temperatura': {
      'Celsius': 1.0,
      'Fahrenheit': 1.0,
      'Kelvin': 1.0,
    },
    'Área': {
      'Metro quadrado': 1.0,
      'Quilômetro quadrado': 0.000001,
      'Hectare': 0.0001,
      'Pé quadrado': 10.7639,
      'Acre': 0.000247105,
      'Milha quadrada': 0.000000386102,
    },
  };

  final Map<String, IconData> _categoryIcons = {
    'Comprimento': Icons.straighten_rounded,
    'Peso': Icons.scale_rounded,
    'Volume': Icons.local_drink_rounded,
    'Temperatura': Icons.thermostat_rounded,
    'Área': Icons.crop_square_rounded,
  };

  final Map<String, Color> _categoryColors = {
    'Comprimento': const Color(0xFF3B82F6),
    'Peso': const Color(0xFF10B981),
    'Volume': const Color(0xFFF59E0B),
    'Temperatura': const Color(0xFFEF4444),
    'Área': const Color(0xFF8B5CF6),
  };

  @override
  void initState() {
    super.initState();
    _inputController.addListener(_convert);
    
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    
    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));
    
    _animationController.forward();
  }

  @override
  void dispose() {
    _inputController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  void _convert() {
    final input = double.tryParse(_inputController.text);
    if (input == null || _inputController.text.isEmpty) {
      setState(() {
        _result = '';
      });
      return;
    }

    double result;
    
    if (_selectedCategory == 'Temperatura') {
      result = _convertTemperature(input);
    } else {
      final fromFactor = _conversionFactors[_selectedCategory]![_fromUnit]!;
      final toFactor = _conversionFactors[_selectedCategory]![_toUnit]!;
      result = input * (toFactor / fromFactor);
    }

    setState(() {
      _result = result.toStringAsFixed(6).replaceAll(RegExp(r'\.?0+$'), '');
    });
  }

  double _convertTemperature(double input) {
    switch (_fromUnit) {
      case 'Celsius':
        switch (_toUnit) {
          case 'Fahrenheit':
            return (input * 9/5) + 32;
          case 'Kelvin':
            return input + 273.15;
          default:
            return input;
        }
      case 'Fahrenheit':
        switch (_toUnit) {
          case 'Celsius':
            return (input - 32) * 5/9;
          case 'Kelvin':
            return (input - 32) * 5/9 + 273.15;
          default:
            return input;
        }
      case 'Kelvin':
        switch (_toUnit) {
          case 'Celsius':
            return input - 273.15;
          case 'Fahrenheit':
            return (input - 273.15) * 9/5 + 32;
          default:
            return input;
        }
      default:
        return input;
    }
  }

  void _swapUnits() {
    setState(() {
      final temp = _fromUnit;
      _fromUnit = _toUnit;
      _toUnit = temp;
    });
    _convert();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: ModernAppBar(
        title: 'Conversor de Unidades',
        leading: const ModernBackButton(),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Theme.of(context).colorScheme.primary.withOpacity(0.05),
              Theme.of(context).colorScheme.secondary.withOpacity(0.05),
            ],
          ),
        ),
        child: SafeArea(
          child: FadeTransition(
            opacity: _fadeAnimation,
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildCategorySelector(),
                  const SizedBox(height: 24),
                  _buildInputSection(),
                  const SizedBox(height: 20),
                  _buildSwapButton(),
                  const SizedBox(height: 20),
                  _buildResultSection(),
                  const SizedBox(height: 32),
                  _buildInfoCard(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCategorySelector() {
    return ModernCardSection(
      title: 'Categoria',
      icon: Icons.category_rounded,
      iconColor: _categoryColors[_selectedCategory],
      child: ModernDropdown<String>(
        value: _selectedCategory,
        items: _conversionFactors.keys.map((String category) {
          return DropdownMenuItem<String>(
            value: category,
            child: Row(
              children: [
                Icon(
                  _categoryIcons[category],
                  size: 20,
                  color: _categoryColors[category],
                ),
                const SizedBox(width: 12),
                Text(category),
              ],
            ),
          );
        }).toList(),
        onChanged: (String? newValue) {
          if (newValue != null) {
            setState(() {
              _selectedCategory = newValue;
              _fromUnit = _conversionFactors[newValue]!.keys.first;
              _toUnit = _conversionFactors[newValue]!.keys.elementAt(1);
            });
            _convert();
          }
        },
      ),
    );
  }

  Widget _buildInputSection() {
    return ModernCardSection(
      title: 'De',
      icon: Icons.input_rounded,
      iconColor: _categoryColors[_selectedCategory],
      child: Column(
        children: [
          ModernInput(
            controller: _inputController,
            hintText: 'Digite o valor',
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            inputFormatters: [
              FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d*')),
            ],
            prefixIcon: Icons.edit_rounded,
          ),
          const SizedBox(height: 16),
          ModernDropdown<String>(
            value: _fromUnit,
            items: _conversionFactors[_selectedCategory]!.keys.map((String unit) {
              return DropdownMenuItem<String>(
                value: unit,
                child: Text(unit),
              );
            }).toList(),
            onChanged: (String? newValue) {
              if (newValue != null) {
                setState(() {
                  _fromUnit = newValue;
                });
                _convert();
              }
            },
          ),
        ],
      ),
    );
  }

  Widget _buildSwapButton() {
    return Center(
      child: ModernButton(
        text: 'Trocar Unidades',
        icon: Icons.swap_vert_rounded,
        onPressed: _swapUnits,
        backgroundColor: _categoryColors[_selectedCategory],
        width: 200,
      ),
    );
  }

  Widget _buildResultSection() {
    return ModernCardSection(
      title: 'Para',
      icon: Icons.output_rounded,
      iconColor: _categoryColors[_selectedCategory],
      child: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: _categoryColors[_selectedCategory]!.withOpacity(0.1),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: _categoryColors[_selectedCategory]!.withOpacity(0.3),
                width: 2,
              ),
            ),
            child: Column(
              children: [
                Icon(
                  Icons.calculate_rounded,
                  size: 32,
                  color: _categoryColors[_selectedCategory],
                ),
                const SizedBox(height: 12),
                Text(
                  _result.isEmpty ? '0' : _result,
                  style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: _categoryColors[_selectedCategory],
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          ModernDropdown<String>(
            value: _toUnit,
            items: _conversionFactors[_selectedCategory]!.keys.map((String unit) {
              return DropdownMenuItem<String>(
                value: unit,
                child: Text(unit),
              );
            }).toList(),
            onChanged: (String? newValue) {
              if (newValue != null) {
                setState(() {
                  _toUnit = newValue;
                });
                _convert();
              }
            },
          ),
        ],
      ),
    );
  }

  Widget _buildInfoCard() {
    return ModernCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.blue.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(
                  Icons.info_rounded,
                  color: Colors.blue,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Text(
                'Como usar',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          _buildInfoStep('1', 'Selecione a categoria de conversão'),
          _buildInfoStep('2', 'Digite o valor a ser convertido'),
          _buildInfoStep('3', 'Escolha as unidades de origem e destino'),
          _buildInfoStep('4', 'O resultado será exibido automaticamente'),
        ],
      ),
    );
  }

  Widget _buildInfoStep(String number, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          Container(
            width: 24,
            height: 24,
            decoration: BoxDecoration(
              color: _categoryColors[_selectedCategory],
              borderRadius: BorderRadius.circular(12),
            ),
            child: Center(
              child: Text(
                number,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              text,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ),
        ],
      ),
    );
  }
}

