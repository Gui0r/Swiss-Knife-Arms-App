import 'dart:math';
import 'package:flutter/material.dart';
import 'package:math_expressions/math_expressions.dart';
import '../widgets/custom_card.dart';
import '../widgets/custom_button.dart';

class CalculatorScreen extends StatefulWidget {
  const CalculatorScreen({super.key});

  @override
  State<CalculatorScreen> createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> {
  String _display = '0';
  String _expression = '';
  bool _isScientificMode = false;
  bool _isNewOperation = true;

  void _onButtonPressed(String value) {
    setState(() {
      if (_isNewOperation && value != 'C' && value != 'CE' && value != '±' && value != '%') {
        _display = '';
        _expression = '';
        _isNewOperation = false;
      }

      switch (value) {
        case 'C':
          _display = '0';
          _expression = '';
          _isNewOperation = true;
          break;
        case 'CE':
          if (_display.length > 1) {
            _display = _display.substring(0, _display.length - 1);
          } else {
            _display = '0';
          }
          break;
        case '±':
          if (_display != '0') {
            if (_display.startsWith('-')) {
              _display = _display.substring(1);
            } else {
              _display = '-$_display';
            }
          }
          break;
        case '=':
          _calculate();
          break;
        case '.':
          if (!_display.contains('.')) {
            _display += '.';
          }
          break;
        case 'sin':
        case 'cos':
        case 'tan':
        case 'log':
        case 'ln':
        case '√':
        case 'x²':
        case 'x³':
        case '1/x':
          _handleScientificFunction(value);
          break;
        default:
          if (_display == '0' && value != '.') {
            _display = value;
          } else {
            _display += value;
          }
      }
    });
  }

  void _handleScientificFunction(String function) {
    try {
      double value = double.parse(_display);
      double result = 0;

      switch (function) {
        case 'sin':
          result = _sin(value);
          break;
        case 'cos':
          result = _cos(value);
          break;
        case 'tan':
          result = _tan(value);
          break;
        case 'log':
          result = _log(value);
          break;
        case 'ln':
          result = _ln(value);
          break;
        case '√':
          result = _sqrt(value);
          break;
        case 'x²':
          result = value * value;
          break;
        case 'x³':
          result = value * value * value;
          break;
        case '1/x':
          result = 1 / value;
          break;
      }

      _display = _formatResult(result);
      _isNewOperation = true;
    } catch (e) {
      _display = 'Erro';
      _isNewOperation = true;
    }
  }

  double _sin(double value) {
    return sin(value * pi / 180);
  }

  double _cos(double value) {
    return cos(value * pi / 180);
  }

  double _tan(double value) {
    return tan(value * pi / 180);
  }

  double _log(double value) {
    return log(value) / ln10;
  }

  double _ln(double value) {
    return log(value);
  }

  double _sqrt(double value) {
    return sqrt(value);
  }

  void _calculate() {
    try {
      _expression = _display;
      _expression = _expression.replaceAll('×', '*');
      _expression = _expression.replaceAll('÷', '/');
      _expression = _expression.replaceAll('π', '3.14159265359');
      _expression = _expression.replaceAll('e', '2.71828182846');

      Parser p = Parser();
      Expression exp = p.parse(_expression);
      ContextModel cm = ContextModel();
      double result = exp.evaluate(EvaluationType.REAL, cm);

      _display = _formatResult(result);
      _isNewOperation = true;
    } catch (e) {
      _display = 'Erro';
      _isNewOperation = true;
    }
  }

  String _formatResult(double result) {
    if (result == result.toInt()) {
      return result.toInt().toString();
    } else {
      return result.toStringAsFixed(8).replaceAll(RegExp(r'\.?0+$'), '');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Calculadora'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          Switch(
            value: _isScientificMode,
            onChanged: (value) {
              setState(() {
                _isScientificMode = value;
                if (value) {
                  _display = '0';
                  _expression = '';
                  _isNewOperation = true;
                }
              });
            },
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Theme.of(context).colorScheme.primary.withOpacity(0.1),
              Theme.of(context).colorScheme.secondary.withOpacity(0.1),
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Display
              CustomCard(
                margin: const EdgeInsets.all(16),
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.black87,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        _expression,
                        style: const TextStyle(
                          color: Colors.grey,
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        _display,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 32,
                          fontWeight: FontWeight.bold,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
              ),
              // Buttons
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: _isScientificMode ? _buildScientificButtons() : _buildBasicButtons(),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBasicButtons() {
    return GridView.count(
      crossAxisCount: 4,
      crossAxisSpacing: 8,
      mainAxisSpacing: 8,
      childAspectRatio: 1.2,
      children: [
        _buildButton('C', Colors.red),
        _buildButton('CE', Colors.red),
        _buildButton('±', Colors.orange),
        _buildButton('÷', Colors.orange),
        _buildButton('7', Colors.grey[300]!),
        _buildButton('8', Colors.grey[300]!),
        _buildButton('9', Colors.grey[300]!),
        _buildButton('×', Colors.orange),
        _buildButton('4', Colors.grey[300]!),
        _buildButton('5', Colors.grey[300]!),
        _buildButton('6', Colors.grey[300]!),
        _buildButton('-', Colors.orange),
        _buildButton('1', Colors.grey[300]!),
        _buildButton('2', Colors.grey[300]!),
        _buildButton('3', Colors.grey[300]!),
        _buildButton('+', Colors.orange),
        _buildButton('0', Colors.grey[300]!, flex: 2),
        _buildButton('.', Colors.grey[300]!),
        _buildButton('=', Colors.blue, flex: 2),
      ],
    );
  }

  Widget _buildScientificButtons() {
    return GridView.count(
      crossAxisCount: 5,
      crossAxisSpacing: 6,
      mainAxisSpacing: 6,
      childAspectRatio: 1.1,
      children: [
        _buildButton('C', Colors.red),
        _buildButton('CE', Colors.red),
        _buildButton('±', Colors.orange),
        _buildButton('π', Colors.blue),
        _buildButton('e', Colors.blue),
        _buildButton('sin', Colors.purple),
        _buildButton('cos', Colors.purple),
        _buildButton('tan', Colors.purple),
        _buildButton('log', Colors.purple),
        _buildButton('ln', Colors.purple),
        _buildButton('√', Colors.purple),
        _buildButton('x²', Colors.purple),
        _buildButton('x³', Colors.purple),
        _buildButton('1/x', Colors.purple),
        _buildButton('÷', Colors.orange),
        _buildButton('7', Colors.grey[300]!),
        _buildButton('8', Colors.grey[300]!),
        _buildButton('9', Colors.grey[300]!),
        _buildButton('×', Colors.orange),
        _buildButton('(', Colors.blue),
        _buildButton('4', Colors.grey[300]!),
        _buildButton('5', Colors.grey[300]!),
        _buildButton('6', Colors.grey[300]!),
        _buildButton('-', Colors.orange),
        _buildButton(')', Colors.blue),
        _buildButton('1', Colors.grey[300]!),
        _buildButton('2', Colors.grey[300]!),
        _buildButton('3', Colors.grey[300]!),
        _buildButton('+', Colors.orange),
        _buildButton('%', Colors.blue),
        _buildButton('0', Colors.grey[300]!),
        _buildButton('.', Colors.grey[300]!),
        _buildButton('=', Colors.green),
      ],
    );
  }

  Widget _buildButton(String text, Color color, {int flex = 1}) {
    return GestureDetector(
      onTap: () => _onButtonPressed(text),
      child: Container(
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(8),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 2,
              offset: const Offset(0, 1),
            ),
          ],
        ),
        child: Center(
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              text,
              style: TextStyle(
                fontSize: text.length > 3 ? 12 : 18,
                fontWeight: FontWeight.bold,
                color: color == Colors.grey[300] ? Colors.black : Colors.white,
              ),
              textAlign: TextAlign.center,
            ),
          ),
        ),
      ),
    );
  }
}
