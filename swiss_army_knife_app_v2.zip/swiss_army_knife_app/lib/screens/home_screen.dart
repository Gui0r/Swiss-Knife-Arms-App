import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../widgets/custom_card.dart';
import '../widgets/custom_button.dart';
import '../widgets/overflow_safe_widget.dart';
import '../widgets/smart_grid.dart';
import 'unit_converter_screen.dart';
import 'measure_converter_screen.dart';
import 'text_tools_screen.dart';
import 'calculator_screen.dart';
import 'password_generator_screen.dart';
import 'currency_converter_screen.dart';
import 'date_time_tools_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();
    
    // Controlador único para otimização
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOutBack,
    ));

    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        title: const Text(
          'Swiss Army Knife',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Theme.of(context).colorScheme.surface,
        foregroundColor: Theme.of(context).colorScheme.onSurface,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.menu_rounded),
            onPressed: () => _scaffoldKey.currentState?.openEndDrawer(),
          ),
        ],
      ),
      endDrawer: _buildDrawer(),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Theme.of(context).colorScheme.primary.withOpacity(0.05),
              Theme.of(context).colorScheme.secondary.withOpacity(0.05),
            ],
          ),
        ),
        child: SafeArea(
          child: AnimatedBuilder(
            animation: _animationController,
            builder: (context, child) {
              return FadeTransition(
                opacity: _fadeAnimation,
                child: SlideTransition(
                  position: _slideAnimation,
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(20.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildWelcomeSection(),
                        const SizedBox(height: 32),
                        _buildToolsGrid(),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildWelcomeSection() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Theme.of(context).colorScheme.primary,
            Theme.of(context).colorScheme.secondary,
          ],
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Theme.of(context).colorScheme.primary.withOpacity(0.3),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: ResponsiveRow(
        spacing: 16,
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.2),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Icon(
              Icons.build_circle_rounded,
              size: 48,
              color: Colors.white,
            ),
          ),
          Flexible(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Bem-vindo!',
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Seu canivete suíço digital com todas as ferramentas que você precisa em um só lugar!',
                  style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                    color: Colors.white.withOpacity(0.9),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildToolsGrid() {
    final tools = [
      {
        'title': 'Conversor de Unidades',
        'subtitle': 'Converta medidas facilmente',
        'icon': Icons.straighten_rounded,
        'color': const Color(0xFF3B82F6), // Blue
        'screen': const UnitConverterScreen(),
      },
      {
        'title': 'Conversor de Medidas',
        'subtitle': 'Sistema métrico e imperial',
        'icon': Icons.architecture_rounded,
        'color': const Color(0xFF10B981), // Green
        'screen': const MeasureConverterScreen(),
      },
      {
        'title': 'Ferramentas de Texto',
        'subtitle': 'Manipule textos facilmente',
        'icon': Icons.text_fields_rounded,
        'color': const Color(0xFFF59E0B), // Orange
        'screen': const TextToolsScreen(),
      },
      {
        'title': 'Calculadora',
        'subtitle': 'Cálculos básicos e científicos',
        'icon': Icons.calculate_rounded,
        'color': const Color(0xFF8B5CF6), // Purple
        'screen': const CalculatorScreen(),
      },
      {
        'title': 'Gerador de Senhas',
        'subtitle': 'Senhas seguras e personalizadas',
        'icon': Icons.lock_rounded,
        'color': const Color(0xFFEF4444), // Red
        'screen': const PasswordGeneratorScreen(),
      },
      {
        'title': 'Conversor de Moedas',
        'subtitle': 'Taxas de câmbio atualizadas',
        'icon': Icons.currency_exchange_rounded,
        'color': const Color(0xFF14B8A6), // Teal
        'screen': const CurrencyConverterScreen(),
      },
      {
        'title': 'Data e Hora',
        'subtitle': 'Ferramentas de tempo',
        'icon': Icons.schedule_rounded,
        'color': const Color(0xFF6366F1), // Indigo
        'screen': const DateTimeToolsScreen(),
      },
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Ferramentas Disponíveis',
          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        SmartGridView(
          maxColumns: 2,
          spacing: 16,
          runSpacing: 16,
          childAspectRatio: 1.1,
          children: tools.map((tool) {
            return _buildToolCard(tool);
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildToolCard(Map<String, dynamic> tool) {
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () => _navigateToScreen(tool['screen'] as Widget),
          borderRadius: BorderRadius.circular(20),
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: (tool['color'] as Color).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Icon(
                    tool['icon'] as IconData,
                    size: 32,
                    color: tool['color'] as Color,
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  tool['title'] as String,
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),
                Text(
                  tool['subtitle'] as String,
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDrawer() {
    return Drawer(
      child: Column(
        children: [
          Container(
            height: 200,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Theme.of(context).colorScheme.primary,
                  Theme.of(context).colorScheme.secondary,
                ],
              ),
            ),
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(
                        Icons.build_circle_rounded,
                        size: 40,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'Swiss Army Knife',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const Text(
                      'Ferramentas em um só lugar',
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                ListTile(
                  leading: const Icon(Icons.home_rounded),
                  title: const Text('Início'),
                  onTap: () => Navigator.pop(context),
                ),
                const Divider(),
                ListTile(
                  leading: const Icon(Icons.straighten_rounded),
                  title: const Text('Conversor de Unidades'),
                  onTap: () => _navigateToScreen(const UnitConverterScreen()),
                ),
                ListTile(
                  leading: const Icon(Icons.architecture_rounded),
                  title: const Text('Conversor de Medidas'),
                  onTap: () => _navigateToScreen(const MeasureConverterScreen()),
                ),
                ListTile(
                  leading: const Icon(Icons.text_fields_rounded),
                  title: const Text('Ferramentas de Texto'),
                  onTap: () => _navigateToScreen(const TextToolsScreen()),
                ),
                ListTile(
                  leading: const Icon(Icons.calculate_rounded),
                  title: const Text('Calculadora'),
                  onTap: () => _navigateToScreen(const CalculatorScreen()),
                ),
                ListTile(
                  leading: const Icon(Icons.lock_rounded),
                  title: const Text('Gerador de Senhas'),
                  onTap: () => _navigateToScreen(const PasswordGeneratorScreen()),
                ),
                ListTile(
                  leading: const Icon(Icons.currency_exchange_rounded),
                  title: const Text('Conversor de Moedas'),
                  onTap: () => _navigateToScreen(const CurrencyConverterScreen()),
                ),
                ListTile(
                  leading: const Icon(Icons.schedule_rounded),
                  title: const Text('Data e Hora'),
                  onTap: () => _navigateToScreen(const DateTimeToolsScreen()),
                ),
                const Divider(),
                ListTile(
                  leading: const Icon(Icons.info_rounded),
                  title: const Text('Sobre'),
                  onTap: () => _showAboutDialog(),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _navigateToScreen(Widget screen) {
    Navigator.pop(context); // Fecha o drawer
    Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (context, animation, secondaryAnimation) => screen,
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          const begin = Offset(1.0, 0.0);
          const end = Offset.zero;
          const curve = Curves.easeInOut;

          var tween = Tween(begin: begin, end: end).chain(
            CurveTween(curve: curve),
          );

          return SlideTransition(
            position: animation.drive(tween),
            child: child,
          );
        },
        transitionDuration: const Duration(milliseconds: 300),
      ),
    );
  }

  void _showAboutDialog() {
    Navigator.pop(context); // Fecha o drawer
    showAboutDialog(
      context: context,
      applicationName: 'Swiss Army Knife',
      applicationVersion: '2.0.0',
      applicationIcon: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Icon(
          Icons.build_circle_rounded,
          size: 40,
          color: Theme.of(context).colorScheme.primary,
        ),
      ),
      children: [
        const Text(
          'Um aplicativo multifuncional moderno que reúne diversas ferramentas úteis em um só lugar. '
          'Desenvolvido com Flutter para máxima compatibilidade entre plataformas.',
        ),
      ],
    );
  }
}
