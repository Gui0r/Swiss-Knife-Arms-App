import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../widgets/custom_card.dart';
import '../widgets/custom_button.dart';

class MeasureConverterScreen extends StatefulWidget {
  const MeasureConverterScreen({super.key});

  @override
  State<MeasureConverterScreen> createState() => _MeasureConverterScreenState();
}

class _MeasureConverterScreenState extends State<MeasureConverterScreen> {
  final TextEditingController _inputController = TextEditingController();
  String _selectedCategory = 'Comprimento';
  String _fromUnit = 'Metro (m)';
  String _toUnit = 'Pé (ft)';
  String _result = '';

  final Map<String, Map<String, double>> _conversionFactors = {
    'Comprimento': {
      'Metro (m)': 1.0,
      'Pé (ft)': 3.28084,
      'Polegada (in)': 39.3701,
      'Jarda (yd)': 1.09361,
      'Milha (mi)': 0.000621371,
      'Centímetro (cm)': 100.0,
      'Milímetro (mm)': 1000.0,
      'Quilômetro (km)': 0.001,
    },
    'Peso': {
      'Quilograma (kg)': 1.0,
      'Libra (lb)': 2.20462,
      'Onça (oz)': 35.274,
      'Stone (st)': 0.157473,
      'Grama (g)': 1000.0,
      'Tonelada (t)': 0.001,
    },
    'Volume': {
      'Litro (L)': 1.0,
      'Galão US (gal)': 0.264172,
      'Galão UK (gal)': 0.219969,
      'Quarto US (qt)': 1.05669,
      'Pinta US (pt)': 2.11338,
      'Xícara (cup)': 4.22675,
      'Onça fluida (fl oz)': 33.814,
      'Mililitro (mL)': 1000.0,
    },
    'Área': {
      'Metro quadrado (m²)': 1.0,
      'Pé quadrado (ft²)': 10.7639,
      'Polegada quadrada (in²)': 1550.0,
      'Jarda quadrada (yd²)': 1.19599,
      'Acre (ac)': 0.000247105,
      'Hectare (ha)': 0.0001,
      'Quilômetro quadrado (km²)': 0.000001,
    },
    'Velocidade': {
      'Quilômetro por hora (km/h)': 1.0,
      'Milha por hora (mph)': 0.621371,
      'Metro por segundo (m/s)': 0.277778,
      'Pé por segundo (ft/s)': 0.911344,
      'Nó (kn)': 0.539957,
    },
    'Pressão': {
      'Pascal (Pa)': 1.0,
      'Bar (bar)': 0.00001,
      'PSI (psi)': 0.000145038,
      'Atmosfera (atm)': 0.00000986923,
      'Torr (torr)': 0.00750062,
      'Milímetro de mercúrio (mmHg)': 0.00750062,
    },
  };

  @override
  void initState() {
    super.initState();
    _inputController.addListener(_convert);
  }

  @override
  void dispose() {
    _inputController.dispose();
    super.dispose();
  }

  void _convert() {
    final input = double.tryParse(_inputController.text);
    if (input == null || _inputController.text.isEmpty) {
      setState(() {
        _result = '';
      });
      return;
    }

    final fromFactor = _conversionFactors[_selectedCategory]![_fromUnit]!;
    final toFactor = _conversionFactors[_selectedCategory]![_toUnit]!;
    final result = input * (toFactor / fromFactor);

    setState(() {
      _result = result.toStringAsFixed(6).replaceAll(RegExp(r'\.?0+$'), '');
    });
  }

  void _swapUnits() {
    setState(() {
      final temp = _fromUnit;
      _fromUnit = _toUnit;
      _toUnit = temp;
    });
    _convert();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Conversor de Medidas'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Theme.of(context).colorScheme.primary.withOpacity(0.1),
              Theme.of(context).colorScheme.secondary.withOpacity(0.1),
            ],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CustomCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Selecione a categoria:',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 12),
                      DropdownButtonFormField<String>(
                        value: _selectedCategory,
                        decoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        ),
                        items: _conversionFactors.keys.map((String category) {
                          return DropdownMenuItem<String>(
                            value: category,
                            child: Text(category),
                          );
                        }).toList(),
                        onChanged: (String? newValue) {
                          if (newValue != null) {
                            setState(() {
                              _selectedCategory = newValue;
                              _fromUnit = _conversionFactors[newValue]!.keys.first;
                              _toUnit = _conversionFactors[newValue]!.keys.elementAt(1);
                            });
                            _convert();
                          }
                        },
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                CustomCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'De:',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Expanded(
                            flex: 2,
                            child: TextField(
                              controller: _inputController,
                              keyboardType: const TextInputType.numberWithOptions(decimal: true),
                              inputFormatters: [
                                FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d*')),
                              ],
                              decoration: const InputDecoration(
                                border: OutlineInputBorder(),
                                hintText: 'Digite o valor',
                                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: DropdownButtonFormField<String>(
                              value: _fromUnit,
                              decoration: const InputDecoration(
                                border: OutlineInputBorder(),
                                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                              ),
                              items: _conversionFactors[_selectedCategory]!.keys.map((String unit) {
                                return DropdownMenuItem<String>(
                                  value: unit,
                                  child: Text(unit),
                                );
                              }).toList(),
                              onChanged: (String? newValue) {
                                if (newValue != null) {
                                  setState(() {
                                    _fromUnit = newValue;
                                  });
                                  _convert();
                                }
                              },
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                Center(
                  child: CustomButton(
                    text: 'Trocar',
                    icon: Icons.swap_vert,
                    onPressed: _swapUnits,
                    backgroundColor: Theme.of(context).colorScheme.secondary,
                  ),
                ),
                const SizedBox(height: 16),
                CustomCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Para:',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Expanded(
                            flex: 2,
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                              decoration: BoxDecoration(
                                border: Border.all(color: Colors.grey),
                                borderRadius: BorderRadius.circular(4),
                                color: Theme.of(context).colorScheme.surface,
                              ),
                              child: Text(
                                _result.isEmpty ? '0' : _result,
                                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                                  fontWeight: FontWeight.bold,
                                  color: Theme.of(context).colorScheme.primary,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: DropdownButtonFormField<String>(
                              value: _toUnit,
                              decoration: const InputDecoration(
                                border: OutlineInputBorder(),
                                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                              ),
                              items: _conversionFactors[_selectedCategory]!.keys.map((String unit) {
                                return DropdownMenuItem<String>(
                                  value: unit,
                                  child: Text(unit),
                                );
                              }).toList(),
                              onChanged: (String? newValue) {
                                if (newValue != null) {
                                  setState(() {
                                    _toUnit = newValue;
                                  });
                                  _convert();
                                }
                              },
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),
                CustomCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Sistemas de Medidas:',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        '• Sistema Métrico: Metro, Quilograma, Litro\n'
                        '• Sistema Imperial: Pé, Libra, Galão\n'
                        '• Conversões precisas entre sistemas\n'
                        '• Suporte a múltiplas categorias\n'
                        '• Resultados em tempo real',
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
