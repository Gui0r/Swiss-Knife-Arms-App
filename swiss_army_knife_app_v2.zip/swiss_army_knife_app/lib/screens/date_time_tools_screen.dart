import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../widgets/custom_card.dart';
import '../widgets/custom_button.dart';

class DateTimeToolsScreen extends StatefulWidget {
  const DateTimeToolsScreen({super.key});

  @override
  State<DateTimeToolsScreen> createState() => _DateTimeToolsScreenState();
}

class _DateTimeToolsScreenState extends State<DateTimeToolsScreen> {
  final TextEditingController _date1Controller = TextEditingController();
  final TextEditingController _date2Controller = TextEditingController();
  final TextEditingController _timeController = TextEditingController();
  final TextEditingController _timezoneController = TextEditingController();
  
  DateTime? _selectedDate1;
  DateTime? _selectedDate2;
  TimeOfDay? _selectedTime;
  String _selectedTool = 'Calculadora de Diferença';
  String _result = '';
  bool _isRunning = false;
  Duration _elapsedTime = Duration.zero;
  DateTime? _startTime;

  final List<String> _tools = [
    'Calculadora de Diferença',
    'Conversor de Fuso Horário',
    'Cronômetro',
    'Temporizador',
    'Idade Calculada',
    'Dias até Data',
  ];

  final List<String> _timezones = [
    'UTC',
    'America/New_York',
    'America/Chicago',
    'America/Denver',
    'America/Los_Angeles',
    'Europe/London',
    'Europe/Paris',
    'Europe/Berlin',
    'Asia/Tokyo',
    'Asia/Shanghai',
    'Asia/Kolkata',
    'Australia/Sydney',
    'America/Sao_Paulo',
    'America/Argentina/Buenos_Aires',
    'Pacific/Auckland',
  ];

  @override
  void initState() {
    super.initState();
    _selectedDate1 = DateTime.now();
    _selectedDate2 = DateTime.now();
    _selectedTime = TimeOfDay.now();
    _updateControllers();
  }

  @override
  void dispose() {
    _date1Controller.dispose();
    _date2Controller.dispose();
    _timeController.dispose();
    _timezoneController.dispose();
    super.dispose();
  }

  void _updateControllers() {
    _date1Controller.text = DateFormat('dd/MM/yyyy').format(_selectedDate1!);
    _date2Controller.text = DateFormat('dd/MM/yyyy').format(_selectedDate2!);
    _timeController.text = _selectedTime!.format(context);
  }

  Future<void> _selectDate1(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate1!,
      firstDate: DateTime(1900),
      lastDate: DateTime(2100),
    );
    if (picked != null && picked != _selectedDate1) {
      setState(() {
        _selectedDate1 = picked;
        _updateControllers();
      });
    }
  }

  Future<void> _selectDate2(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate2!,
      firstDate: DateTime(1900),
      lastDate: DateTime(2100),
    );
    if (picked != null && picked != _selectedDate2) {
      setState(() {
        _selectedDate2 = picked;
        _updateControllers();
      });
    }
  }

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: _selectedTime!,
    );
    if (picked != null && picked != _selectedTime) {
      setState(() {
        _selectedTime = picked;
        _updateControllers();
      });
    }
  }

  void _calculateDifference() {
    if (_selectedDate1 == null || _selectedDate2 == null) return;

    final difference = _selectedDate2!.difference(_selectedDate1!);
    final days = difference.inDays;
    final hours = difference.inHours;
    final minutes = difference.inMinutes;
    final seconds = difference.inSeconds;

    setState(() {
      _result = 'Diferença: $days dias, ${hours % 24} horas, ${minutes % 60} minutos, ${seconds % 60} segundos';
    });
  }

  void _calculateAge() {
    if (_selectedDate1 == null) return;

    final now = DateTime.now();
    final age = now.difference(_selectedDate1!);
    final years = (age.inDays / 365.25).floor();
    final months = ((age.inDays % 365.25) / 30.44).floor();
    final days = (age.inDays % 30.44).floor();

    setState(() {
      _result = 'Idade: $years anos, $months meses e $days dias';
    });
  }

  void _calculateDaysUntil() {
    if (_selectedDate2 == null) return;

    final now = DateTime.now();
    final difference = _selectedDate2!.difference(now);
    final days = difference.inDays;

    setState(() {
      if (days > 0) {
        _result = 'Faltam $days dias até a data selecionada';
      } else if (days < 0) {
        _result = 'A data já passou há ${-days} dias';
      } else {
        _result = 'A data é hoje!';
      }
    });
  }

  void _startStopwatch() {
    if (_isRunning) {
      setState(() {
        _isRunning = false;
      });
    } else {
      setState(() {
        _isRunning = true;
        _startTime = DateTime.now();
      });
      _updateStopwatch();
    }
  }

  void _resetStopwatch() {
    setState(() {
      _isRunning = false;
      _elapsedTime = Duration.zero;
      _result = '';
    });
  }

  void _updateStopwatch() {
    if (_isRunning) {
      setState(() {
        _elapsedTime = DateTime.now().difference(_startTime!);
        _result = '${_elapsedTime.inHours.toString().padLeft(2, '0')}:'
            '${(_elapsedTime.inMinutes % 60).toString().padLeft(2, '0')}:'
            '${(_elapsedTime.inSeconds % 60).toString().padLeft(2, '0')}';
      });
      Future.delayed(const Duration(seconds: 1), _updateStopwatch);
    }
  }

  void _processTool() {
    switch (_selectedTool) {
      case 'Calculadora de Diferença':
        _calculateDifference();
        break;
      case 'Idade Calculada':
        _calculateAge();
        break;
      case 'Dias até Data':
        _calculateDaysUntil();
        break;
      case 'Conversor de Fuso Horário':
        _convertTimezone();
        break;
      case 'Cronômetro':
        _startStopwatch();
        break;
      case 'Temporizador':
        _startTimer();
        break;
    }
  }

  void _convertTimezone() {
    // Implementação simplificada de conversão de fuso horário
    final now = DateTime.now();
    setState(() {
      _result = 'Hora atual: ${DateFormat('dd/MM/yyyy HH:mm:ss').format(now)}\n'
          'UTC: ${DateFormat('dd/MM/yyyy HH:mm:ss').format(now.toUtc())}';
    });
  }

  void _startTimer() {
    // Implementação simplificada de temporizador
    setState(() {
      _result = 'Temporizador: Funcionalidade em desenvolvimento';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Ferramentas de Data e Hora'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Theme.of(context).colorScheme.primary.withOpacity(0.1),
              Theme.of(context).colorScheme.secondary.withOpacity(0.1),
            ],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Tool Selection
                CustomCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Selecione a ferramenta:',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 12),
                      DropdownButtonFormField<String>(
                        value: _selectedTool,
                        decoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        ),
                        items: _tools.map((String tool) {
                          return DropdownMenuItem<String>(
                            value: tool,
                            child: Text(tool),
                          );
                        }).toList(),
                        onChanged: (String? newValue) {
                          if (newValue != null) {
                            setState(() {
                              _selectedTool = newValue;
                              _result = '';
                            });
                          }
                        },
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                // Date/Time Inputs
                if (_selectedTool == 'Calculadora de Diferença' || 
                    _selectedTool == 'Idade Calculada' || 
                    _selectedTool == 'Dias até Data')
                  _buildDateInputs(),
                if (_selectedTool == 'Conversor de Fuso Horário')
                  _buildTimezoneInputs(),
                if (_selectedTool == 'Cronômetro')
                  _buildStopwatchControls(),
                if (_selectedTool == 'Temporizador')
                  _buildTimerInputs(),
                const SizedBox(height: 16),
                // Action Button
                if (_selectedTool != 'Cronômetro')
                  CustomButton(
                    text: _selectedTool == 'Cronômetro' ? 
                          (_isRunning ? 'Parar' : 'Iniciar') : 
                          'Calcular',
                    icon: _selectedTool == 'Cronômetro' ? 
                          (_isRunning ? Icons.pause : Icons.play_arrow) : 
                          Icons.calculate,
                    onPressed: _processTool,
                    width: double.infinity,
                  ),
                if (_selectedTool == 'Cronômetro')
                  Row(
                    children: [
                      Expanded(
                        child: CustomButton(
                          text: _isRunning ? 'Parar' : 'Iniciar',
                          icon: _isRunning ? Icons.pause : Icons.play_arrow,
                          onPressed: _startStopwatch,
                          backgroundColor: _isRunning ? Colors.red : Colors.green,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: CustomButton(
                          text: 'Resetar',
                          icon: Icons.refresh,
                          onPressed: _resetStopwatch,
                          backgroundColor: Colors.grey,
                        ),
                      ),
                    ],
                  ),
                const SizedBox(height: 16),
                // Result
                if (_result.isNotEmpty)
                  CustomCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Resultado:',
                          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(
                              color: Theme.of(context).colorScheme.primary.withOpacity(0.3),
                            ),
                          ),
                          child: Text(
                            _result,
                            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.bold,
                              color: Theme.of(context).colorScheme.primary,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                const SizedBox(height: 16),
                // Current Time
                CustomCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Data e Hora Atual:',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        DateFormat('EEEE, dd/MM/yyyy HH:mm:ss').format(DateTime.now()),
                        style: Theme.of(context).textTheme.titleSmall?.copyWith(
                          color: Theme.of(context).colorScheme.primary,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDateInputs() {
    return Column(
      children: [
        CustomCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                _selectedTool == 'Idade Calculada' ? 'Data de Nascimento:' : 'Data 1:',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: _date1Controller,
                readOnly: true,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  suffixIcon: Icon(Icons.calendar_today),
                  contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                ),
                onTap: () => _selectDate1(context),
              ),
            ],
          ),
        ),
        if (_selectedTool != 'Idade Calculada' && _selectedTool != 'Dias até Data')
          const SizedBox(height: 16),
        if (_selectedTool != 'Idade Calculada' && _selectedTool != 'Dias até Data')
          CustomCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _selectedTool == 'Dias até Data' ? 'Data Alvo:' : 'Data 2:',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: _date2Controller,
                  readOnly: true,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    suffixIcon: Icon(Icons.calendar_today),
                    contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  ),
                  onTap: () => _selectDate2(context),
                ),
              ],
            ),
          ),
        if (_selectedTool == 'Dias até Data')
          const SizedBox(height: 16),
        if (_selectedTool == 'Dias até Data')
          CustomCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Data Alvo:',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: _date2Controller,
                  readOnly: true,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    suffixIcon: Icon(Icons.calendar_today),
                    contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  ),
                  onTap: () => _selectDate2(context),
                ),
              ],
            ),
          ),
      ],
    );
  }

  Widget _buildTimezoneInputs() {
    return CustomCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Fuso Horário:',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            value: _timezones.first,
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            ),
            items: _timezones.map((String timezone) {
              return DropdownMenuItem<String>(
                value: timezone,
                child: Text(timezone),
              );
            }).toList(),
            onChanged: (String? newValue) {
              // Implementar conversão de fuso horário
            },
          ),
        ],
      ),
    );
  }

  Widget _buildStopwatchControls() {
    return CustomCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Cronômetro:',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          Center(
            child: Text(
              _result.isEmpty ? '00:00:00' : _result,
              style: Theme.of(context).textTheme.headlineLarge?.copyWith(
                fontWeight: FontWeight.bold,
                color: Theme.of(context).colorScheme.primary,
                fontFamily: 'monospace',
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTimerInputs() {
    return CustomCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Temporizador:',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _timeController,
            readOnly: true,
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              suffixIcon: Icon(Icons.access_time),
              contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            ),
            onTap: () => _selectTime(context),
          ),
        ],
      ),
    );
  }
}
