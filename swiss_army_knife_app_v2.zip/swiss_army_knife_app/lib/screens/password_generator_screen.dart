import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../widgets/custom_card.dart';
import '../widgets/custom_button.dart';

class PasswordGeneratorScreen extends StatefulWidget {
  const PasswordGeneratorScreen({super.key});

  @override
  State<PasswordGeneratorScreen> createState() => _PasswordGeneratorScreenState();
}

class _PasswordGeneratorScreenState extends State<PasswordGeneratorScreen> {
  final TextEditingController _passwordController = TextEditingController();
  int _passwordLength = 12;
  bool _includeUppercase = true;
  bool _includeLowercase = true;
  bool _includeNumbers = true;
  bool _includeSymbols = true;
  bool _excludeSimilar = false;
  bool _excludeAmbiguous = false;
  double _passwordStrength = 0.0;
  String _strengthText = '';

  final String _uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  final String _lowercase = 'abcdefghijklmnopqrstuvwxyz';
  final String _numbers = '0123456789';
  final String _symbols = '!@#\$%^&*()_+-=[]{}|;:,.<>?';
  final String _similar = 'il1Lo0O';
  final String _ambiguous = '{}[]()/\\\'"`~,;.<>';

  @override
  void initState() {
    super.initState();
    _generatePassword();
  }

  @override
  void dispose() {
    _passwordController.dispose();
    super.dispose();
  }

  void _generatePassword() {
    String charset = '';
    
    if (_includeUppercase) charset += _uppercase;
    if (_includeLowercase) charset += _lowercase;
    if (_includeNumbers) charset += _numbers;
    if (_includeSymbols) charset += _symbols;
    
    if (charset.isEmpty) {
      _passwordController.text = 'Selecione pelo menos um tipo de caractere';
      return;
    }

    if (_excludeSimilar) {
      for (int i = 0; i < _similar.length; i++) {
        charset = charset.replaceAll(_similar[i], '');
      }
    }

    if (_excludeAmbiguous) {
      for (int i = 0; i < _ambiguous.length; i++) {
        charset = charset.replaceAll(_ambiguous[i], '');
      }
    }

    if (charset.isEmpty) {
      _passwordController.text = 'Charset vazio após exclusões';
      return;
    }

    final random = Random.secure();
    String password = '';
    
    for (int i = 0; i < _passwordLength; i++) {
      password += charset[random.nextInt(charset.length)];
    }

    _passwordController.text = password;
    _calculatePasswordStrength(password);
  }

  void _calculatePasswordStrength(String password) {
    double strength = 0.0;
    String strengthText = '';

    // Length factor
    if (password.length >= 8) strength += 0.2;
    if (password.length >= 12) strength += 0.2;
    if (password.length >= 16) strength += 0.1;

    // Character variety
    bool hasUppercase = password.contains(RegExp(r'[A-Z]'));
    bool hasLowercase = password.contains(RegExp(r'[a-z]'));
    bool hasNumbers = password.contains(RegExp(r'[0-9]'));
    bool hasSymbols = password.contains(RegExp(r'[!@#$%^&*(),.?":{}|<>]'));

    if (hasUppercase) strength += 0.15;
    if (hasLowercase) strength += 0.15;
    if (hasNumbers) strength += 0.15;
    if (hasSymbols) strength += 0.15;

    // Determine strength text
    if (strength < 0.3) {
      strengthText = 'Muito Fraca';
    } else if (strength < 0.5) {
      strengthText = 'Fraca';
    } else if (strength < 0.7) {
      strengthText = 'Média';
    } else if (strength < 0.9) {
      strengthText = 'Forte';
    } else {
      strengthText = 'Muito Forte';
    }

    setState(() {
      _passwordStrength = strength;
      _strengthText = strengthText;
    });
  }

  Color _getStrengthColor() {
    if (_passwordStrength < 0.3) return Colors.red;
    if (_passwordStrength < 0.5) return Colors.orange;
    if (_passwordStrength < 0.7) return Colors.yellow;
    if (_passwordStrength < 0.9) return Colors.lightGreen;
    return Colors.green;
  }

  void _copyPassword() {
    if (_passwordController.text.isNotEmpty) {
      Clipboard.setData(ClipboardData(text: _passwordController.text));
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Senha copiada para a área de transferência!')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Gerador de Senhas'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Theme.of(context).colorScheme.primary.withOpacity(0.1),
              Theme.of(context).colorScheme.secondary.withOpacity(0.1),
            ],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Password Display
                CustomCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Senha Gerada:',
                            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          IconButton(
                            onPressed: _copyPassword,
                            icon: const Icon(Icons.copy),
                            tooltip: 'Copiar senha',
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.grey[100],
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: Colors.grey[300]!),
                        ),
                        child: Text(
                          _passwordController.text,
                          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                            fontFamily: 'monospace',
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Text(
                            'Força: ',
                            style: Theme.of(context).textTheme.bodyMedium,
                          ),
                          Text(
                            _strengthText,
                            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              fontWeight: FontWeight.bold,
                              color: _getStrengthColor(),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: LinearProgressIndicator(
                              value: _passwordStrength,
                              backgroundColor: Colors.grey[300],
                              valueColor: AlwaysStoppedAnimation<Color>(_getStrengthColor()),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                // Length Slider
                CustomCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Comprimento: $_passwordLength caracteres',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Slider(
                        value: _passwordLength.toDouble(),
                        min: 4,
                        max: 50,
                        divisions: 46,
                        onChanged: (value) {
                          setState(() {
                            _passwordLength = value.round();
                          });
                        },
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                // Character Options
                CustomCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Tipos de caracteres:',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 12),
                      SwitchListTile(
                        title: const Text('Maiúsculas (A-Z)'),
                        value: _includeUppercase,
                        onChanged: (value) {
                          setState(() {
                            _includeUppercase = value;
                          });
                        },
                      ),
                      SwitchListTile(
                        title: const Text('Minúsculas (a-z)'),
                        value: _includeLowercase,
                        onChanged: (value) {
                          setState(() {
                            _includeLowercase = value;
                          });
                        },
                      ),
                      SwitchListTile(
                        title: const Text('Números (0-9)'),
                        value: _includeNumbers,
                        onChanged: (value) {
                          setState(() {
                            _includeNumbers = value;
                          });
                        },
                      ),
                      SwitchListTile(
                        title: const Text('Símbolos (!@#...)'),
                        value: _includeSymbols,
                        onChanged: (value) {
                          setState(() {
                            _includeSymbols = value;
                          });
                        },
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                // Exclusion Options
                CustomCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Exclusões:',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 12),
                      SwitchListTile(
                        title: const Text('Excluir caracteres similares (il1Lo0O)'),
                        value: _excludeSimilar,
                        onChanged: (value) {
                          setState(() {
                            _excludeSimilar = value;
                          });
                        },
                      ),
                      SwitchListTile(
                        title: const Text('Excluir caracteres ambíguos ({[()]})'),
                        value: _excludeAmbiguous,
                        onChanged: (value) {
                          setState(() {
                            _excludeAmbiguous = value;
                          });
                        },
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                // Generate Button
                CustomButton(
                  text: 'Gerar Nova Senha',
                  icon: Icons.refresh,
                  onPressed: _generatePassword,
                  width: double.infinity,
                ),
                const SizedBox(height: 16),
                // Tips
                CustomCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Dicas de Segurança:',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        '• Use pelo menos 12 caracteres\n'
                        '• Combine maiúsculas, minúsculas, números e símbolos\n'
                        '• Evite palavras do dicionário\n'
                        '• Não reutilize senhas entre contas\n'
                        '• Use um gerenciador de senhas\n'
                        '• Ative autenticação de dois fatores quando possível',
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
