# Instruções de Execução - Swiss Army Knife App

## 🚀 Execução Rápida

### 1. Instalar Dependências
```bash
flutter pub get
```

### 2. Executar o Projeto

#### Para Web (Recomendado para teste rápido):
```bash
flutter run -d chrome
```

#### Para Android (com emulador ou dispositivo):
```bash
flutter run -d android
```

#### Para ver dispositivos disponíveis:
```bash
flutter devices
```

## 🔨 Build para Produção

### Build Web:
```bash
flutter build web
```
Os arquivos estarão em: `build/web/`

### Build Android:
```bash
flutter build apk --release
```
O APK estará em: `build/app/outputs/flutter-apk/app-release.apk`

### Usando o Script de Build:
```bash
# Windows
build.bat

# Linux/Mac
chmod +x build.sh && ./build.sh
```

## 📱 Testando as Funcionalidades

### 1. Tela Inicial
- Apresenta o propósito do app
- Grid com acesso rápido às ferramentas
- Menu lateral com navegação completa

### 2. Conversor de Unidades
- Selecione categoria (Comprimento, Peso, Volume, etc.)
- Digite o valor
- Escolha unidades de origem e destino
- Resultado automático

### 3. Conversor de Medidas
- Similar ao conversor de unidades
- Foco em sistemas métrico vs imperial
- Botão para trocar unidades

### 4. Ferramentas de Texto
- Digite ou cole texto
- Selecione a ferramenta desejada
- Veja estatísticas em tempo real
- Copie resultado

### 5. Calculadora
- Modo básico por padrão
- Ative modo científico no AppBar
- Suporte a funções trigonométricas
- Constantes π e e

### 6. Gerador de Senhas
- Configure comprimento (4-50)
- Escolha tipos de caracteres
- Veja força da senha
- Copie para área de transferência

### 7. Conversor de Moedas
- Requer conexão com internet
- Taxas atualizadas via API
- 40+ moedas suportadas
- Botão de atualização

### 8. Ferramentas de Data e Hora
- Calculadora de diferença entre datas
- Cálculo de idade
- Cronômetro funcional
- Contagem de dias

## 🐛 Solução de Problemas

### Erro: "No devices found"
```bash
flutter doctor
flutter devices
```

### Erro de dependências:
```bash
flutter clean
flutter pub get
```

### Erro de build:
```bash
flutter clean
flutter pub get
flutter build web
```

### API de moedas não funciona:
- Verifique conexão com internet
- A API pode ter limites de requisições
- Use o botão de atualização

## 📋 Checklist de Funcionalidades

- [ ] Tela inicial carrega corretamente
- [ ] Menu lateral funciona
- [ ] Conversor de unidades converte valores
- [ ] Conversor de medidas funciona
- [ ] Ferramentas de texto processam texto
- [ ] Calculadora faz cálculos básicos
- [ ] Calculadora científica funciona
- [ ] Gerador de senhas gera senhas
- [ ] Conversor de moedas carrega taxas
- [ ] Cronômetro inicia/para/reseta
- [ ] Cálculo de idade funciona
- [ ] Diferença entre datas calcula
- [ ] Botões de copiar funcionam
- [ ] Design responsivo em diferentes telas

## 🎯 Dicas de Uso

1. **Navegação**: Use o menu lateral ou os cards da tela inicial
2. **Cópia**: Muitas ferramentas têm botão de copiar
3. **Tempo Real**: Resultados aparecem automaticamente
4. **Responsivo**: Funciona em desktop, tablet e mobile
5. **Tema**: Suporte automático a tema claro/escuro

## 📞 Suporte

Se encontrar problemas:
1. Verifique se o Flutter está atualizado: `flutter --version`
2. Execute `flutter doctor` para verificar configuração
3. Consulte o README.md para mais detalhes
4. Verifique se todas as dependências estão instaladas

---

**Versão**: 1.0.0  
**Flutter**: 3.0.0+  
**Status**: Pronto para uso
